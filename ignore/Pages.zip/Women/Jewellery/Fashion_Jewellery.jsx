﻿import React from 'react';

const FashionJewellery = () => {
    return (
        <div>
            <h1>FashionJewellery Component</h1>
        </div>
    );
}

export default FashionJewellery;
