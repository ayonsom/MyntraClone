﻿import React from 'react';

const FineJewellery = () => {
    return (
        <div>
            <h1>FineJewellery Component</h1>
        </div>
    );
}

export default FineJewellery;
