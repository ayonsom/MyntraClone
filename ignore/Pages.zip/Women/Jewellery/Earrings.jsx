﻿import React from 'react';

const Earrings = () => {
    return (
        <div>
            <h1>Earrings Component</h1>
        </div>
    );
}

export default Earrings;
