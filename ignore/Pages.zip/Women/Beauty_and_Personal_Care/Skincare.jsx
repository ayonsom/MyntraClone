﻿import React from 'react';

const Skincare = () => {
    return (
        <div>
            <h1>Skincare Component</h1>
        </div>
    );
}

export default Skincare;
