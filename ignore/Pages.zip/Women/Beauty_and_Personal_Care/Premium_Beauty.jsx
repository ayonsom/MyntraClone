﻿import React from 'react';

const PremiumBeauty = () => {
    return (
        <div>
            <h1>PremiumBeauty Component</h1>
        </div>
    );
}

export default PremiumBeauty;
