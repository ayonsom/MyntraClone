﻿import React from 'react';

const Fragrances = () => {
    return (
        <div>
            <h1>Fragrances Component</h1>
        </div>
    );
}

export default Fragrances;
