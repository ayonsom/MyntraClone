﻿import React from 'react';

const Lipsticks = () => {
    return (
        <div>
            <h1>Lipsticks Component</h1>
        </div>
    );
}

export default Lipsticks;
