﻿import React from 'react';

const Makeup = () => {
    return (
        <div>
            <h1>Makeup Component</h1>
        </div>
    );
}

export default Makeup;
