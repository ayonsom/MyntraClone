﻿import React from 'react';

const BlazersAndWaistcoats = () => {
    return (
        <div>
            <h1>BlazersAndWaistcoats Component</h1>
        </div>
    );
}

export default BlazersAndWaistcoats;
