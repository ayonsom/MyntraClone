﻿import React from 'react';

const Jumpsuits = () => {
    return (
        <div>
            <h1>Jumpsuits Component</h1>
        </div>
    );
}

export default Jumpsuits;
