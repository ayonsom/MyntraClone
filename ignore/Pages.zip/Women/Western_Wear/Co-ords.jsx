﻿import React from 'react';

const Co-ords = () => {
    return (
        <div>
            <h1>Co-ords Component</h1>
        </div>
    );
}

export default Co-ords;
