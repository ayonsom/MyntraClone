﻿import React from 'react';

const JacketsAndCoats = () => {
    return (
        <div>
            <h1>JacketsAndCoats Component</h1>
        </div>
    );
}

export default JacketsAndCoats;
