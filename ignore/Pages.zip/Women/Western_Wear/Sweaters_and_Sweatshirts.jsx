﻿import React from 'react';

const SweatersAndSweatshirts = () => {
    return (
        <div>
            <h1>SweatersAndSweatshirts Component</h1>
        </div>
    );
}

export default SweatersAndSweatshirts;
