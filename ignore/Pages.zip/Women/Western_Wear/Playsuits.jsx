﻿import React from 'react';

const Playsuits = () => {
    return (
        <div>
            <h1>Playsuits Component</h1>
        </div>
    );
}

export default Playsuits;
