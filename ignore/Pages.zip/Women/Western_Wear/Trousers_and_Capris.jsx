﻿import React from 'react';

const TrousersAndCapris = () => {
    return (
        <div>
            <h1>TrousersAndCapris Component</h1>
        </div>
    );
}

export default TrousersAndCapris;
