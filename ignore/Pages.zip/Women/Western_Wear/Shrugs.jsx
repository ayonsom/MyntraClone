﻿import React from 'react';

const Shrugs = () => {
    return (
        <div>
            <h1>Shrugs Component</h1>
        </div>
    );
}

export default Shrugs;
