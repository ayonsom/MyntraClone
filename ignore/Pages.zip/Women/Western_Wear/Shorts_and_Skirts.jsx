﻿import React from 'react';

const ShortsAndSkirts = () => {
    return (
        <div>
            <h1>ShortsAndSkirts Component</h1>
        </div>
    );
}

export default ShortsAndSkirts;
