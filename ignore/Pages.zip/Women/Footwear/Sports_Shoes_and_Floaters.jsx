﻿import React from 'react';

const SportsShoesAndFloaters = () => {
    return (
        <div>
            <h1>SportsShoesAndFloaters Component</h1>
        </div>
    );
}

export default SportsShoesAndFloaters;
