﻿import React from 'react';

const Boots = () => {
    return (
        <div>
            <h1>Boots Component</h1>
        </div>
    );
}

export default Boots;
