﻿import React from 'react';

const SkirtsAndPalazzos = () => {
    return (
        <div>
            <h1>SkirtsAndPalazzos Component</h1>
        </div>
    );
}

export default SkirtsAndPalazzos;
