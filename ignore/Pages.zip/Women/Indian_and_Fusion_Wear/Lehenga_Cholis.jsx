﻿import React from 'react';

const LehengaCholis = () => {
    return (
        <div>
            <h1>LehengaCholis Component</h1>
        </div>
    );
}

export default LehengaCholis;
