﻿import React from 'react';

const KurtasAndSuits = () => {
    return (
        <div>
            <h1>KurtasAndSuits Component</h1>
        </div>
    );
}

export default KurtasAndSuits;
