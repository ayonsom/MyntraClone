﻿import React from 'react';

const LeggingsSalwarsAndChuridars = () => {
    return (
        <div>
            <h1>LeggingsSalwarsAndChuridars Component</h1>
        </div>
    );
}

export default LeggingsSalwarsAndChuridars;
