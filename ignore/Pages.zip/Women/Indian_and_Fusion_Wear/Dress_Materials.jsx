﻿import React from 'react';

const DressMaterials = () => {
    return (
        <div>
            <h1>DressMaterials Component</h1>
        </div>
    );
}

export default DressMaterials;
