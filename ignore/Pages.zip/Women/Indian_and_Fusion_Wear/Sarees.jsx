﻿import React from 'react';

const Sarees = () => {
    return (
        <div>
            <h1>Sarees Component</h1>
        </div>
    );
}

export default Sarees;
