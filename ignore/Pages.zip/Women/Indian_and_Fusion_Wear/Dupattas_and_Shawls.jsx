﻿import React from 'react';

const DupattasAndShawls = () => {
    return (
        <div>
            <h1>DupattasAndShawls Component</h1>
        </div>
    );
}

export default DupattasAndShawls;
