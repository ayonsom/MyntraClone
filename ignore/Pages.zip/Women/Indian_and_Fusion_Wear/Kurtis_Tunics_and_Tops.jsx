﻿import React from 'react';

const KurtisTunicsAndTops = () => {
    return (
        <div>
            <h1>KurtisTunicsAndTops Component</h1>
        </div>
    );
}

export default KurtisTunicsAndTops;
