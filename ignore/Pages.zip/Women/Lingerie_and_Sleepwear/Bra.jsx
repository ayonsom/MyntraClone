﻿import React from 'react';

const Bra = () => {
    return (
        <div>
            <h1>Bra Component</h1>
        </div>
    );
}

export default Bra;
