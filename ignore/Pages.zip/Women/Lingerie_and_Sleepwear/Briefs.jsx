﻿import React from 'react';

const Briefs = () => {
    return (
        <div>
            <h1>Briefs Component</h1>
        </div>
    );
}

export default Briefs;
