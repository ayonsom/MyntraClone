﻿import React from 'react';

const CamisolesAndThermals = () => {
    return (
        <div>
            <h1>CamisolesAndThermals Component</h1>
        </div>
    );
}

export default CamisolesAndThermals;
