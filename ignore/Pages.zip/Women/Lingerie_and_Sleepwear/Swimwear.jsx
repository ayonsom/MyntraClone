﻿import React from 'react';

const Swimwear = () => {
    return (
        <div>
            <h1>Swimwear Component</h1>
        </div>
    );
}

export default Swimwear;
