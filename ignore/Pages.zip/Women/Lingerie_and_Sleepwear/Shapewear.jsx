﻿import React from 'react';

const Shapewear = () => {
    return (
        <div>
            <h1>Shapewear Component</h1>
        </div>
    );
}

export default Shapewear;
