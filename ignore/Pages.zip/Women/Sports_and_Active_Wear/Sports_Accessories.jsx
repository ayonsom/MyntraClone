﻿import React from 'react';

const SportsAccessories = () => {
    return (
        <div>
            <h1>SportsAccessories Component</h1>
        </div>
    );
}

export default SportsAccessories;
