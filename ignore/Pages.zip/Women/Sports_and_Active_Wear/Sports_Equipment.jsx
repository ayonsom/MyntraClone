﻿import React from 'react';

const SportsEquipment = () => {
    return (
        <div>
            <h1>SportsEquipment Component</h1>
        </div>
    );
}

export default SportsEquipment;
