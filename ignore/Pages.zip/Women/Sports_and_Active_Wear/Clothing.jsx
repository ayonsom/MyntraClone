﻿import React from 'react';

const Clothing = () => {
    return (
        <div>
            <h1>Clothing Component</h1>
        </div>
    );
}

export default Clothing;
