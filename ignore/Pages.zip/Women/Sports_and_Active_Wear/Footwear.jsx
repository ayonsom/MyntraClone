﻿import React from 'react';

const Footwear = () => {
    return (
        <div>
            <h1>Footwear Component</h1>
        </div>
    );
}

export default Footwear;
