﻿import React from 'react';

const LehengaCholi = () => {
    return (
        <div>
            <h1>LehengaCholi Component</h1>
        </div>
    );
}

export default LehengaCholi;
