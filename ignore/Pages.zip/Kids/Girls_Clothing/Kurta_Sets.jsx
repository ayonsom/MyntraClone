﻿import React from 'react';

const KurtaSets = () => {
    return (
        <div>
            <h1>KurtaSets Component</h1>
        </div>
    );
}

export default KurtaSets;
