﻿import React from 'react';

const JeansTrousersAndCapris = () => {
    return (
        <div>
            <h1>JeansTrousersAndCapris Component</h1>
        </div>
    );
}

export default JeansTrousersAndCapris;
