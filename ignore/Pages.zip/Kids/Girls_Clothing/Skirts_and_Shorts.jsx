﻿import React from 'react';

const SkirtsAndShorts = () => {
    return (
        <div>
            <h1>SkirtsAndShorts Component</h1>
        </div>
    );
}

export default SkirtsAndShorts;
