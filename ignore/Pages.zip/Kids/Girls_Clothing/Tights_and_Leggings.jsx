﻿import React from 'react';

const TightsAndLeggings = () => {
    return (
        <div>
            <h1>TightsAndLeggings Component</h1>
        </div>
    );
}

export default TightsAndLeggings;
