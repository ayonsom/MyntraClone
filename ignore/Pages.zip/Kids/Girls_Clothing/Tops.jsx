﻿import React from 'react';

const Tops = () => {
    return (
        <div>
            <h1>Tops Component</h1>
        </div>
    );
}

export default Tops;
