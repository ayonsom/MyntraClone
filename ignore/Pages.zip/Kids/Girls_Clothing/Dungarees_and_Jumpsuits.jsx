﻿import React from 'react';

const DungareesAndJumpsuits = () => {
    return (
        <div>
            <h1>DungareesAndJumpsuits Component</h1>
        </div>
    );
}

export default DungareesAndJumpsuits;
