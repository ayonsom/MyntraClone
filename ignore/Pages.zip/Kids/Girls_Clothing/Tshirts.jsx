﻿import React from 'react';

const Tshirts = () => {
    return (
        <div>
            <h1>Tshirts Component</h1>
        </div>
    );
}

export default Tshirts;
