﻿import React from 'react';

const Dresses = () => {
    return (
        <div>
            <h1>Dresses Component</h1>
        </div>
    );
}

export default Dresses;
