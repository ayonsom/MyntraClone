﻿import React from 'react';

const MasksAndProtectiveGears = () => {
    return (
        <div>
            <h1>MasksAndProtectiveGears Component</h1>
        </div>
    );
}

export default MasksAndProtectiveGears;
