﻿import React from 'react';

const CapsAndHats = () => {
    return (
        <div>
            <h1>CapsAndHats Component</h1>
        </div>
    );
}

export default CapsAndHats;
