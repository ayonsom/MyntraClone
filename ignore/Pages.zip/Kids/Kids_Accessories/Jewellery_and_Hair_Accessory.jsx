﻿import React from 'react';

const JewelleryAndHairAccessory = () => {
    return (
        <div>
            <h1>JewelleryAndHairAccessory Component</h1>
        </div>
    );
}

export default JewelleryAndHairAccessory;
