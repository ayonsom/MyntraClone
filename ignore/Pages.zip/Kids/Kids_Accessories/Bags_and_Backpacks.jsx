﻿import React from 'react';

const BagsAndBackpacks = () => {
    return (
        <div>
            <h1>BagsAndBackpacks Component</h1>
        </div>
    );
}

export default BagsAndBackpacks;
