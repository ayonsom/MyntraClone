﻿import React from 'react';

const Watches = () => {
    return (
        <div>
            <h1>Watches Component</h1>
        </div>
    );
}

export default Watches;
