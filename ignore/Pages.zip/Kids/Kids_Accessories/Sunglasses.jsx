﻿import React from 'react';

const Sunglasses = () => {
    return (
        <div>
            <h1>Sunglasses Component</h1>
        </div>
    );
}

export default Sunglasses;
