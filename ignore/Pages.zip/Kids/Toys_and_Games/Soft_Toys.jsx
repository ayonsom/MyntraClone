﻿import React from 'react';

const SoftToys = () => {
    return (
        <div>
            <h1>SoftToys Component</h1>
        </div>
    );
}

export default SoftToys;
