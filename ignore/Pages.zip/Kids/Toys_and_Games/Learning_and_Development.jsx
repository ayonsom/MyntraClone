﻿import React from 'react';

const LearningAndDevelopment = () => {
    return (
        <div>
            <h1>LearningAndDevelopment Component</h1>
        </div>
    );
}

export default LearningAndDevelopment;
