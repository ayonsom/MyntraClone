﻿import React from 'react';

const ActionFigureAndPlaySet = () => {
    return (
        <div>
            <h1>ActionFigureAndPlaySet Component</h1>
        </div>
    );
}

export default ActionFigureAndPlaySet;
