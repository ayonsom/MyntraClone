﻿import React from 'react';

const ActivityToys = () => {
    return (
        <div>
            <h1>ActivityToys Component</h1>
        </div>
    );
}

export default ActivityToys;
