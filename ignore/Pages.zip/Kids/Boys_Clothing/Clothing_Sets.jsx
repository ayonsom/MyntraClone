﻿import React from 'react';

const ClothingSets = () => {
    return (
        <div>
            <h1>ClothingSets Component</h1>
        </div>
    );
}

export default ClothingSets;
