﻿import React from 'react';

const JacketSweaterAndSweatshirts = () => {
    return (
        <div>
            <h1>JacketSweaterAndSweatshirts Component</h1>
        </div>
    );
}

export default JacketSweaterAndSweatshirts;
