﻿import React from 'react';

const Jeans = () => {
    return (
        <div>
            <h1>Jeans Component</h1>
        </div>
    );
}

export default Jeans;
