﻿import React from 'react';

const Trousers = () => {
    return (
        <div>
            <h1>Trousers Component</h1>
        </div>
    );
}

export default Trousers;
