﻿import React from 'react';

const InnerwearAndThermals = () => {
    return (
        <div>
            <h1>InnerwearAndThermals Component</h1>
        </div>
    );
}

export default InnerwearAndThermals;
