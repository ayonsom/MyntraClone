﻿import React from 'react';

const NightwearAndLoungewear = () => {
    return (
        <div>
            <h1>NightwearAndLoungewear Component</h1>
        </div>
    );
}

export default NightwearAndLoungewear;
