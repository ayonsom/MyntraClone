﻿import React from 'react';

const EthnicWear = () => {
    return (
        <div>
            <h1>EthnicWear Component</h1>
        </div>
    );
}

export default EthnicWear;
