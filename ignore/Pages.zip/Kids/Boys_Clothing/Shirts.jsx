﻿import React from 'react';

const Shirts = () => {
    return (
        <div>
            <h1>Shirts Component</h1>
        </div>
    );
}

export default Shirts;
