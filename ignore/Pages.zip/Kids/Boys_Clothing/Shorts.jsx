﻿import React from 'react';

const Shorts = () => {
    return (
        <div>
            <h1>Shorts Component</h1>
        </div>
    );
}

export default Shorts;
