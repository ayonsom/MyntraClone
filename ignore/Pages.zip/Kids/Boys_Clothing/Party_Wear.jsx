﻿import React from 'react';

const PartyWear = () => {
    return (
        <div>
            <h1>PartyWear Component</h1>
        </div>
    );
}

export default PartyWear;
