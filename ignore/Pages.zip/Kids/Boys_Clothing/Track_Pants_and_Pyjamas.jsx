﻿import React from 'react';

const TrackPantsAndPyjamas = () => {
    return (
        <div>
            <h1>TrackPantsAndPyjamas Component</h1>
        </div>
    );
}

export default TrackPantsAndPyjamas;
