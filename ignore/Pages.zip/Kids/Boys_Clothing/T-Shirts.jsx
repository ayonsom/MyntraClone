﻿import React from 'react';

const T-Shirts = () => {
    return (
        <div>
            <h1>T-Shirts Component</h1>
        </div>
    );
}

export default T-Shirts;
