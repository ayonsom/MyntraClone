﻿import React from 'react';

const ValuePacks = () => {
    return (
        <div>
            <h1>ValuePacks Component</h1>
        </div>
    );
}

export default ValuePacks;
