﻿import React from 'react';

const Bodysuits = () => {
    return (
        <div>
            <h1>Bodysuits Component</h1>
        </div>
    );
}

export default Bodysuits;
