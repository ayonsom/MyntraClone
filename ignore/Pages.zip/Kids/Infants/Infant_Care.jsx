﻿import React from 'react';

const InfantCare = () => {
    return (
        <div>
            <h1>InfantCare Component</h1>
        </div>
    );
}

export default InfantCare;
