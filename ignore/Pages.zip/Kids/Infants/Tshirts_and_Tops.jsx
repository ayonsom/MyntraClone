﻿import React from 'react';

const TshirtsAndTops = () => {
    return (
        <div>
            <h1>TshirtsAndTops Component</h1>
        </div>
    );
}

export default TshirtsAndTops;
