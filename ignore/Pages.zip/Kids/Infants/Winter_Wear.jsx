﻿import React from 'react';

const WinterWear = () => {
    return (
        <div>
            <h1>WinterWear Component</h1>
        </div>
    );
}

export default WinterWear;
