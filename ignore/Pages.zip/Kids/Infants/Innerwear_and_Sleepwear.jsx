﻿import React from 'react';

const InnerwearAndSleepwear = () => {
    return (
        <div>
            <h1>InnerwearAndSleepwear Component</h1>
        </div>
    );
}

export default InnerwearAndSleepwear;
