﻿import React from 'react';

const BottomWear = () => {
    return (
        <div>
            <h1>BottomWear Component</h1>
        </div>
    );
}

export default BottomWear;
