﻿import React from 'react';

const YK = () => {
    return (
        <div>
            <h1>YK Component</h1>
        </div>
    );
}

export default YK;
