﻿import React from 'react';

const UnitedColorsOfBenettonKids = () => {
    return (
        <div>
            <h1>UnitedColorsOfBenettonKids Component</h1>
        </div>
    );
}

export default UnitedColorsOfBenettonKids;
