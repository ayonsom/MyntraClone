﻿import React from 'react';

const HM = () => {
    return (
        <div>
            <h1>HM Component</h1>
        </div>
    );
}

export default HM;
