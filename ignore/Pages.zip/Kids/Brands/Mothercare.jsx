﻿import React from 'react';

const Mothercare = () => {
    return (
        <div>
            <h1>Mothercare Component</h1>
        </div>
    );
}

export default Mothercare;
