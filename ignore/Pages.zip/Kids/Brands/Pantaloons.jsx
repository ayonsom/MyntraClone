﻿import React from 'react';

const Pantaloons = () => {
    return (
        <div>
            <h1>Pantaloons Component</h1>
        </div>
    );
}

export default Pantaloons;
