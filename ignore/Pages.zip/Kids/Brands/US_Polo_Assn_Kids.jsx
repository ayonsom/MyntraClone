﻿import React from 'react';

const USPoloAssnKids = () => {
    return (
        <div>
            <h1>USPoloAssnKids Component</h1>
        </div>
    );
}

export default USPoloAssnKids;
