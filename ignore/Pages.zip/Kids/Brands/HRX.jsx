﻿import React from 'react';

const HRX = () => {
    return (
        <div>
            <h1>HRX Component</h1>
        </div>
    );
}

export default HRX;
