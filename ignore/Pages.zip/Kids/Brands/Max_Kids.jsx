﻿import React from 'react';

const MaxKids = () => {
    return (
        <div>
            <h1>MaxKids Component</h1>
        </div>
    );
}

export default MaxKids;
