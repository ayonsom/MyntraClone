﻿import React from 'react';

const CasualShoes = () => {
    return (
        <div>
            <h1>CasualShoes Component</h1>
        </div>
    );
}

export default CasualShoes;
