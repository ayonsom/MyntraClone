﻿import React from 'react';

const Flats = () => {
    return (
        <div>
            <h1>Flats Component</h1>
        </div>
    );
}

export default Flats;
