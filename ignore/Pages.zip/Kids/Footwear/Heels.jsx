﻿import React from 'react';

const Heels = () => {
    return (
        <div>
            <h1>Heels Component</h1>
        </div>
    );
}

export default Heels;
