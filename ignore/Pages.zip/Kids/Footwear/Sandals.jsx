﻿import React from 'react';

const Sandals = () => {
    return (
        <div>
            <h1>Sandals Component</h1>
        </div>
    );
}

export default Sandals;
