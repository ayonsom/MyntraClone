﻿import React from 'react';

const SportsShoes = () => {
    return (
        <div>
            <h1>SportsShoes Component</h1>
        </div>
    );
}

export default SportsShoes;
