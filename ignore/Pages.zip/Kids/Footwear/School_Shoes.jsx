﻿import React from 'react';

const SchoolShoes = () => {
    return (
        <div>
            <h1>SchoolShoes Component</h1>
        </div>
    );
}

export default SchoolShoes;
