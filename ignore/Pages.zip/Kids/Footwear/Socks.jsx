﻿import React from 'react';

const Socks = () => {
    return (
        <div>
            <h1>Socks Component</h1>
        </div>
    );
}

export default Socks;
