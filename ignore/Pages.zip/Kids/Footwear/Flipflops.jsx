﻿import React from 'react';

const Flipflops = () => {
    return (
        <div>
            <h1>Flipflops Component</h1>
        </div>
    );
}

export default Flipflops;
