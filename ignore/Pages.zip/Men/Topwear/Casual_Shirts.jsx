﻿import React from 'react';

const CasualShirts = () => {
    return (
        <div>
            <h1>CasualShirts Component</h1>
        </div>
    );
}

export default CasualShirts;
