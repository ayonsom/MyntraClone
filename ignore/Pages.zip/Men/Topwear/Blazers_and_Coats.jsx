﻿import React from 'react';

const BlazersAndCoats = () => {
    return (
        <div>
            <h1>BlazersAndCoats Component</h1>
        </div>
    );
}

export default BlazersAndCoats;
