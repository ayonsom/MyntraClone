﻿import React from 'react';

const Suits = () => {
    return (
        <div>
            <h1>Suits Component</h1>
        </div>
    );
}

export default Suits;
