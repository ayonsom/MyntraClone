﻿import React from 'react';

const FormalShirts = () => {
    return (
        <div>
            <h1>FormalShirts Component</h1>
        </div>
    );
}

export default FormalShirts;
