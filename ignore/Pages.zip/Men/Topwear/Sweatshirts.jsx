﻿import React from 'react';

const Sweatshirts = () => {
    return (
        <div>
            <h1>Sweatshirts Component</h1>
        </div>
    );
}

export default Sweatshirts;
