﻿import React from 'react';

const Sweaters = () => {
    return (
        <div>
            <h1>Sweaters Component</h1>
        </div>
    );
}

export default Sweaters;
