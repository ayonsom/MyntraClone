﻿import React from 'react';

const Jackets = () => {
    return (
        <div>
            <h1>Jackets Component</h1>
        </div>
    );
}

export default Jackets;
