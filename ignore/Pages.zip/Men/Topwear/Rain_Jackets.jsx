﻿import React from 'react';

const RainJackets = () => {
    return (
        <div>
            <h1>RainJackets Component</h1>
        </div>
    );
}

export default RainJackets;
