﻿import React from 'react';

const BriefsAndTrunks = () => {
    return (
        <div>
            <h1>BriefsAndTrunks Component</h1>
        </div>
    );
}

export default BriefsAndTrunks;
