﻿import React from 'react';

const Thermals = () => {
    return (
        <div>
            <h1>Thermals Component</h1>
        </div>
    );
}

export default Thermals;
