﻿import React from 'react';

const SleepwearAndLoungewear = () => {
    return (
        <div>
            <h1>SleepwearAndLoungewear Component</h1>
        </div>
    );
}

export default SleepwearAndLoungewear;
