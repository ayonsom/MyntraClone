﻿import React from 'react';

const Boxers = () => {
    return (
        <div>
            <h1>Boxers Component</h1>
        </div>
    );
}

export default Boxers;
