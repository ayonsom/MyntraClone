﻿import React from 'react';

const Vests = () => {
    return (
        <div>
            <h1>Vests Component</h1>
        </div>
    );
}

export default Vests;
