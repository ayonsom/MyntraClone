﻿import React from 'react';

const TrackPantsAndJoggers = () => {
    return (
        <div>
            <h1>TrackPantsAndJoggers Component</h1>
        </div>
    );
}

export default TrackPantsAndJoggers;
