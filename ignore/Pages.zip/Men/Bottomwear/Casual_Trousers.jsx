﻿import React from 'react';

const CasualTrousers = () => {
    return (
        <div>
            <h1>CasualTrousers Component</h1>
        </div>
    );
}

export default CasualTrousers;
