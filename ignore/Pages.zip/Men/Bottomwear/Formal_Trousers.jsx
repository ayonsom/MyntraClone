﻿import React from 'react';

const FormalTrousers = () => {
    return (
        <div>
            <h1>FormalTrousers Component</h1>
        </div>
    );
}

export default FormalTrousers;
