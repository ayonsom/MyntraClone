﻿import React from 'react';

const Speakers = () => {
    return (
        <div>
            <h1>Speakers Component</h1>
        </div>
    );
}

export default Speakers;
