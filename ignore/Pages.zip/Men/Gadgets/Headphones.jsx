﻿import React from 'react';

const Headphones = () => {
    return (
        <div>
            <h1>Headphones Component</h1>
        </div>
    );
}

export default Headphones;
