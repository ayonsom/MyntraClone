﻿import React from 'react';

const FitnessGadgets = () => {
    return (
        <div>
            <h1>FitnessGadgets Component</h1>
        </div>
    );
}

export default FitnessGadgets;
