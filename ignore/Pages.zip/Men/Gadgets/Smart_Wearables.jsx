﻿import React from 'react';

const SmartWearables = () => {
    return (
        <div>
            <h1>SmartWearables Component</h1>
        </div>
    );
}

export default SmartWearables;
