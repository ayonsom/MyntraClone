﻿import React from 'react';

const Dhotis = () => {
    return (
        <div>
            <h1>Dhotis Component</h1>
        </div>
    );
}

export default Dhotis;
