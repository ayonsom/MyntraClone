﻿import React from 'react';

const KurtasAndKurtaSets = () => {
    return (
        <div>
            <h1>KurtasAndKurtaSets Component</h1>
        </div>
    );
}

export default KurtasAndKurtaSets;
