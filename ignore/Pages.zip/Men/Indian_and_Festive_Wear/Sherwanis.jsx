﻿import React from 'react';

const Sherwanis = () => {
    return (
        <div>
            <h1>Sherwanis Component</h1>
        </div>
    );
}

export default Sherwanis;
