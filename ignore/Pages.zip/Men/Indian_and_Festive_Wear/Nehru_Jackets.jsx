﻿import React from 'react';

const NehruJackets = () => {
    return (
        <div>
            <h1>NehruJackets Component</h1>
        </div>
    );
}

export default NehruJackets;
