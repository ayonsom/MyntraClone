﻿import React from 'react';

const Belts = () => {
    return (
        <div>
            <h1>Belts Component</h1>
        </div>
    );
}

export default Belts;
