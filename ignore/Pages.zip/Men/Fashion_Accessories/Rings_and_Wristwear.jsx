﻿import React from 'react';

const RingsAndWristwear = () => {
    return (
        <div>
            <h1>RingsAndWristwear Component</h1>
        </div>
    );
}

export default RingsAndWristwear;
