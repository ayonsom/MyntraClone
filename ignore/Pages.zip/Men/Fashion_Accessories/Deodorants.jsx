﻿import React from 'react';

const Deodorants = () => {
    return (
        <div>
            <h1>Deodorants Component</h1>
        </div>
    );
}

export default Deodorants;
