﻿import React from 'react';

const TiesCufflinksAndPocketSquares = () => {
    return (
        <div>
            <h1>TiesCufflinksAndPocketSquares Component</h1>
        </div>
    );
}

export default TiesCufflinksAndPocketSquares;
