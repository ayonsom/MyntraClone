﻿import React from 'react';

const Wallets = () => {
    return (
        <div>
            <h1>Wallets Component</h1>
        </div>
    );
}

export default Wallets;
