﻿import React from 'react';

const MufflersScarvesAndGloves = () => {
    return (
        <div>
            <h1>MufflersScarvesAndGloves Component</h1>
        </div>
    );
}

export default MufflersScarvesAndGloves;
