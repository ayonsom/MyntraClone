﻿import React from 'react';

const PerfumesAndBodyMists = () => {
    return (
        <div>
            <h1>PerfumesAndBodyMists Component</h1>
        </div>
    );
}

export default PerfumesAndBodyMists;
