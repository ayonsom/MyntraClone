﻿import React from 'react';

const PhoneCases = () => {
    return (
        <div>
            <h1>PhoneCases Component</h1>
        </div>
    );
}

export default PhoneCases;
