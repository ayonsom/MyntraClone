﻿import React from 'react';

const AccessoryGiftSets = () => {
    return (
        <div>
            <h1>AccessoryGiftSets Component</h1>
        </div>
    );
}

export default AccessoryGiftSets;
