﻿import React from 'react';

const Trimmers = () => {
    return (
        <div>
            <h1>Trimmers Component</h1>
        </div>
    );
}

export default Trimmers;
