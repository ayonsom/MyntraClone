﻿import React from 'react';

const Helmets = () => {
    return (
        <div>
            <h1>Helmets Component</h1>
        </div>
    );
}

export default Helmets;
