﻿import React from 'react';

const LipGloss = () => {
    return (
        <div>
            <h1>LipGloss Component</h1>
        </div>
    );
}

export default LipGloss;
