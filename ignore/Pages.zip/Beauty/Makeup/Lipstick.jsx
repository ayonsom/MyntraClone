﻿import React from 'react';

const Lipstick = () => {
    return (
        <div>
            <h1>Lipstick Component</h1>
        </div>
    );
}

export default Lipstick;
