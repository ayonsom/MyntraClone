﻿import React from 'react';

const Foundation = () => {
    return (
        <div>
            <h1>Foundation Component</h1>
        </div>
    );
}

export default Foundation;
