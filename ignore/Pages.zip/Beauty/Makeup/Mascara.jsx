﻿import React from 'react';

const Mascara = () => {
    return (
        <div>
            <h1>Mascara Component</h1>
        </div>
    );
}

export default Mascara;
