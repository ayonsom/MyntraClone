﻿import React from 'react';

const LipLiner = () => {
    return (
        <div>
            <h1>LipLiner Component</h1>
        </div>
    );
}

export default LipLiner;
