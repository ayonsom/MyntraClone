﻿import React from 'react';

const Kajal = () => {
    return (
        <div>
            <h1>Kajal Component</h1>
        </div>
    );
}

export default Kajal;
