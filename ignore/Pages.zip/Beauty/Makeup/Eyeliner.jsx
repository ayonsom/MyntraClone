﻿import React from 'react';

const Eyeliner = () => {
    return (
        <div>
            <h1>Eyeliner Component</h1>
        </div>
    );
}

export default Eyeliner;
