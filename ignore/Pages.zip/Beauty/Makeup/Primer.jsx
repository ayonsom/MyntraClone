﻿import React from 'react';

const Primer = () => {
    return (
        <div>
            <h1>Primer Component</h1>
        </div>
    );
}

export default Primer;
