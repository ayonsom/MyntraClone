﻿import React from 'react';

const Concealer = () => {
    return (
        <div>
            <h1>Concealer Component</h1>
        </div>
    );
}

export default Concealer;
