﻿import React from 'react';

const NailPolish = () => {
    return (
        <div>
            <h1>NailPolish Component</h1>
        </div>
    );
}

export default NailPolish;
