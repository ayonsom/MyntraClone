﻿import React from 'react';

const Eyeshadow = () => {
    return (
        <div>
            <h1>Eyeshadow Component</h1>
        </div>
    );
}

export default Eyeshadow;
