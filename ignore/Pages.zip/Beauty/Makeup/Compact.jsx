﻿import React from 'react';

const Compact = () => {
    return (
        <div>
            <h1>Compact Component</h1>
        </div>
    );
}

export default Compact;
