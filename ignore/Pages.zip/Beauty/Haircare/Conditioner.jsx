﻿import React from 'react';

const Conditioner = () => {
    return (
        <div>
            <h1>Conditioner Component</h1>
        </div>
    );
}

export default Conditioner;
