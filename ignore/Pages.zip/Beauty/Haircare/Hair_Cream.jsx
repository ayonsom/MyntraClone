﻿import React from 'react';

const HairCream = () => {
    return (
        <div>
            <h1>HairCream Component</h1>
        </div>
    );
}

export default HairCream;
