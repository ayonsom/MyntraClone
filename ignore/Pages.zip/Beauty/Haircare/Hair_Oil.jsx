﻿import React from 'react';

const HairOil = () => {
    return (
        <div>
            <h1>HairOil Component</h1>
        </div>
    );
}

export default HairOil;
