﻿import React from 'react';

const HairGel = () => {
    return (
        <div>
            <h1>HairGel Component</h1>
        </div>
    );
}

export default HairGel;
