﻿import React from 'react';

const HairAccessory = () => {
    return (
        <div>
            <h1>HairAccessory Component</h1>
        </div>
    );
}

export default HairAccessory;
