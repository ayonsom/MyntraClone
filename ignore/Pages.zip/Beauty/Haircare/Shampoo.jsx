﻿import React from 'react';

const Shampoo = () => {
    return (
        <div>
            <h1>Shampoo Component</h1>
        </div>
    );
}

export default Shampoo;
