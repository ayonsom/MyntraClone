﻿import React from 'react';

const HairColor = () => {
    return (
        <div>
            <h1>HairColor Component</h1>
        </div>
    );
}

export default HairColor;
