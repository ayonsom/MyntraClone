﻿import React from 'react';

const HandCream = () => {
    return (
        <div>
            <h1>HandCream Component</h1>
        </div>
    );
}

export default HandCream;
