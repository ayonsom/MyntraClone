﻿import React from 'react';

const LipBalm = () => {
    return (
        <div>
            <h1>LipBalm Component</h1>
        </div>
    );
}

export default LipBalm;
