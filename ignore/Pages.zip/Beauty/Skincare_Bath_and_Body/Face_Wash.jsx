﻿import React from 'react';

const FaceWash = () => {
    return (
        <div>
            <h1>FaceWash Component</h1>
        </div>
    );
}

export default FaceWash;
