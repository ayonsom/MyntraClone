﻿import React from 'react';

const Cleanser = () => {
    return (
        <div>
            <h1>Cleanser Component</h1>
        </div>
    );
}

export default Cleanser;
