﻿import React from 'react';

const Serum = () => {
    return (
        <div>
            <h1>Serum Component</h1>
        </div>
    );
}

export default Serum;
