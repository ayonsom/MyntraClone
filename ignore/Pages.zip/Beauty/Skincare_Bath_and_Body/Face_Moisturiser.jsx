﻿import React from 'react';

const FaceMoisturiser = () => {
    return (
        <div>
            <h1>FaceMoisturiser Component</h1>
        </div>
    );
}

export default FaceMoisturiser;
