﻿import React from 'react';

const MasksAndPeel = () => {
    return (
        <div>
            <h1>MasksAndPeel Component</h1>
        </div>
    );
}

export default MasksAndPeel;
