﻿import React from 'react';

const BodyLotion = () => {
    return (
        <div>
            <h1>BodyLotion Component</h1>
        </div>
    );
}

export default BodyLotion;
