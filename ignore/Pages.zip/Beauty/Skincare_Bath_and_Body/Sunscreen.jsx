﻿import React from 'react';

const Sunscreen = () => {
    return (
        <div>
            <h1>Sunscreen Component</h1>
        </div>
    );
}

export default Sunscreen;
