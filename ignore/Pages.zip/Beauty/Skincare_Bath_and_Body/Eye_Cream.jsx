﻿import React from 'react';

const EyeCream = () => {
    return (
        <div>
            <h1>EyeCream Component</h1>
        </div>
    );
}

export default EyeCream;
