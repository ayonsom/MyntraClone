﻿import React from 'react';

const BodyWash = () => {
    return (
        <div>
            <h1>BodyWash Component</h1>
        </div>
    );
}

export default BodyWash;
