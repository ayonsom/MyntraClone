﻿import React from 'react';

const BodyScrub = () => {
    return (
        <div>
            <h1>BodyScrub Component</h1>
        </div>
    );
}

export default BodyScrub;
