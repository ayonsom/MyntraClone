﻿import React from 'react';

const PillowsAndPillowCovers = () => {
    return (
        <div>
            <h1>PillowsAndPillowCovers Component</h1>
        </div>
    );
}

export default PillowsAndPillowCovers;
