﻿import React from 'react';

const MattressProtectors = () => {
    return (
        <div>
            <h1>MattressProtectors Component</h1>
        </div>
    );
}

export default MattressProtectors;
