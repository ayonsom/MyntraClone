﻿import React from 'react';

const BedRunners = () => {
    return (
        <div>
            <h1>BedRunners Component</h1>
        </div>
    );
}

export default BedRunners;
