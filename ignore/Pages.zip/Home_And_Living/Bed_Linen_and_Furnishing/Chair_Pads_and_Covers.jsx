﻿import React from 'react';

const ChairPadsAndCovers = () => {
    return (
        <div>
            <h1>ChairPadsAndCovers Component</h1>
        </div>
    );
}

export default ChairPadsAndCovers;
