﻿import React from 'react';

const BeddingSets = () => {
    return (
        <div>
            <h1>BeddingSets Component</h1>
        </div>
    );
}

export default BeddingSets;
