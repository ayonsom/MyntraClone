﻿import React from 'react';

const SofaCovers = () => {
    return (
        <div>
            <h1>SofaCovers Component</h1>
        </div>
    );
}

export default SofaCovers;
