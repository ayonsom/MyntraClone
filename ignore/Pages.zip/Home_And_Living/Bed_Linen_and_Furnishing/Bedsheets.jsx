﻿import React from 'react';

const Bedsheets = () => {
    return (
        <div>
            <h1>Bedsheets Component</h1>
        </div>
    );
}

export default Bedsheets;
