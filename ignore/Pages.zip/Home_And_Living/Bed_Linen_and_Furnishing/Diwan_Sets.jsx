﻿import React from 'react';

const DiwanSets = () => {
    return (
        <div>
            <h1>DiwanSets Component</h1>
        </div>
    );
}

export default DiwanSets;
