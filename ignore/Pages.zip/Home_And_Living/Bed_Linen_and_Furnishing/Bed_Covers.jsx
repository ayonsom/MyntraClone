﻿import React from 'react';

const BedCovers = () => {
    return (
        <div>
            <h1>BedCovers Component</h1>
        </div>
    );
}

export default BedCovers;
