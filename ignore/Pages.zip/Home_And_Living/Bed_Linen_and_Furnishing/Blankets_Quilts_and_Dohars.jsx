﻿import React from 'react';

const BlanketsQuiltsAndDohars = () => {
    return (
        <div>
            <h1>BlanketsQuiltsAndDohars Component</h1>
        </div>
    );
}

export default BlanketsQuiltsAndDohars;
