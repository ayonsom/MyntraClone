﻿import React from 'react';

const DinnerwareAndServeware = () => {
    return (
        <div>
            <h1>DinnerwareAndServeware Component</h1>
        </div>
    );
}

export default DinnerwareAndServeware;
