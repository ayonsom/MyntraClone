﻿import React from 'react';

const CupsAndMugs = () => {
    return (
        <div>
            <h1>CupsAndMugs Component</h1>
        </div>
    );
}

export default CupsAndMugs;
