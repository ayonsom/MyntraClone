﻿import React from 'react';

const BarAndDrinkware = () => {
    return (
        <div>
            <h1>BarAndDrinkware Component</h1>
        </div>
    );
}

export default BarAndDrinkware;
