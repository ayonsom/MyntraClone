﻿import React from 'react';

const TableRunners = () => {
    return (
        <div>
            <h1>TableRunners Component</h1>
        </div>
    );
}

export default TableRunners;
