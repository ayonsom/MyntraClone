﻿import React from 'react';

const BakewareAndCookware = () => {
    return (
        <div>
            <h1>BakewareAndCookware Component</h1>
        </div>
    );
}

export default BakewareAndCookware;
