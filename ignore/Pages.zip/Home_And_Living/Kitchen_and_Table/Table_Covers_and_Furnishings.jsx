﻿import React from 'react';

const TableCoversAndFurnishings = () => {
    return (
        <div>
            <h1>TableCoversAndFurnishings Component</h1>
        </div>
    );
}

export default TableCoversAndFurnishings;
