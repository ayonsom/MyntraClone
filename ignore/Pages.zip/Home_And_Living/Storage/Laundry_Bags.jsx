﻿import React from 'react';

const LaundryBags = () => {
    return (
        <div>
            <h1>LaundryBags Component</h1>
        </div>
    );
}

export default LaundryBags;
