﻿import React from 'react';

const HooksAndHolders = () => {
    return (
        <div>
            <h1>HooksAndHolders Component</h1>
        </div>
    );
}

export default HooksAndHolders;
