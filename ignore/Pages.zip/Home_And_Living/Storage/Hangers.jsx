﻿import React from 'react';

const Hangers = () => {
    return (
        <div>
            <h1>Hangers Component</h1>
        </div>
    );
}

export default Hangers;
