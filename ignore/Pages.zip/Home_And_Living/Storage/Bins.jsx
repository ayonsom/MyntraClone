﻿import React from 'react';

const Bins = () => {
    return (
        <div>
            <h1>Bins Component</h1>
        </div>
    );
}

export default Bins;
