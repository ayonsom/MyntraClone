﻿import React from 'react';

const DoorMats = () => {
    return (
        <div>
            <h1>DoorMats Component</h1>
        </div>
    );
}

export default DoorMats;
