﻿import React from 'react';

const FloorRunners = () => {
    return (
        <div>
            <h1>FloorRunners Component</h1>
        </div>
    );
}

export default FloorRunners;
