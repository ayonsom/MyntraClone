﻿import React from 'react';

const Carpets = () => {
    return (
        <div>
            <h1>Carpets Component</h1>
        </div>
    );
}

export default Carpets;
