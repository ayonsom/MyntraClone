﻿import React from 'react';

const FloorMatsAndDhurries = () => {
    return (
        <div>
            <h1>FloorMatsAndDhurries Component</h1>
        </div>
    );
}

export default FloorMatsAndDhurries;
