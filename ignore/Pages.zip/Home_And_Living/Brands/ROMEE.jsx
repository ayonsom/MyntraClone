﻿import React from 'react';

const ROMEE = () => {
    return (
        <div>
            <h1>ROMEE Component</h1>
        </div>
    );
}

export default ROMEE;
