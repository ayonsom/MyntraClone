﻿import React from 'react';

const Story@Home = () => {
    return (
        <div>
            <h1>Story@Home Component</h1>
        </div>
    );
}

export default Story@Home;
