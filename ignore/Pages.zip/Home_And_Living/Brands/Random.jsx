﻿import React from 'react';

const Random = () => {
    return (
        <div>
            <h1>Random Component</h1>
        </div>
    );
}

export default Random;
