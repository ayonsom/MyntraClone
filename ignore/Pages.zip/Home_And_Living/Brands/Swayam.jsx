﻿import React from 'react';

const Swayam = () => {
    return (
        <div>
            <h1>Swayam Component</h1>
        </div>
    );
}

export default Swayam;
