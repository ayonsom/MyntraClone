﻿import React from 'react';

const RaymondHome = () => {
    return (
        <div>
            <h1>RaymondHome Component</h1>
        </div>
    );
}

export default RaymondHome;
