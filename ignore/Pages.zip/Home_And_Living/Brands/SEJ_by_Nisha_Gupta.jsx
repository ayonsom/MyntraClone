﻿import React from 'react';

const SEJbyNishaGupta = () => {
    return (
        <div>
            <h1>SEJbyNishaGupta Component</h1>
        </div>
    );
}

export default SEJbyNishaGupta;
