﻿import React from 'react';

const Maspar = () => {
    return (
        <div>
            <h1>Maspar Component</h1>
        </div>
    );
}

export default Maspar;
