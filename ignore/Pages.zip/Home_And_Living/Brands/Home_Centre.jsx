﻿import React from 'react';

const HomeCentre = () => {
    return (
        <div>
            <h1>HomeCentre Component</h1>
        </div>
    );
}

export default HomeCentre;
