﻿import React from 'react';

const Ellementry = () => {
    return (
        <div>
            <h1>Ellementry Component</h1>
        </div>
    );
}

export default Ellementry;
