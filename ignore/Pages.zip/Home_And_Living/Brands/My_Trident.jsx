﻿import React from 'react';

const MyTrident = () => {
    return (
        <div>
            <h1>MyTrident Component</h1>
        </div>
    );
}

export default MyTrident;
