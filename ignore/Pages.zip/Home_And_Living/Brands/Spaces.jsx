﻿import React from 'react';

const Spaces = () => {
    return (
        <div>
            <h1>Spaces Component</h1>
        </div>
    );
}

export default Spaces;
