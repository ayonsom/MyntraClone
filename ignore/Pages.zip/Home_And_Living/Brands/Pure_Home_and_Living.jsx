﻿import React from 'react';

const PureHomeAndLiving = () => {
    return (
        <div>
            <h1>PureHomeAndLiving Component</h1>
        </div>
    );
}

export default PureHomeAndLiving;
