﻿import React from 'react';

const Cortina = () => {
    return (
        <div>
            <h1>Cortina Component</h1>
        </div>
    );
}

export default Cortina;
