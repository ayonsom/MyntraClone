﻿import React from 'react';

const DDécor = () => {
    return (
        <div>
            <h1>DDécor Component</h1>
        </div>
    );
}

export default DDécor;
