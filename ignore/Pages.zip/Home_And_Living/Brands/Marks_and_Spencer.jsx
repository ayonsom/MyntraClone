﻿import React from 'react';

const MarksAndSpencer = () => {
    return (
        <div>
            <h1>MarksAndSpencer Component</h1>
        </div>
    );
}

export default MarksAndSpencer;
