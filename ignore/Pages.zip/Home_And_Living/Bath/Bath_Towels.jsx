﻿import React from 'react';

const BathTowels = () => {
    return (
        <div>
            <h1>BathTowels Component</h1>
        </div>
    );
}

export default BathTowels;
