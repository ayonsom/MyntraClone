﻿import React from 'react';

const TowelsSet = () => {
    return (
        <div>
            <h1>TowelsSet Component</h1>
        </div>
    );
}

export default TowelsSet;
