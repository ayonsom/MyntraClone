﻿import React from 'react';

const BathroomAccessories = () => {
    return (
        <div>
            <h1>BathroomAccessories Component</h1>
        </div>
    );
}

export default BathroomAccessories;
