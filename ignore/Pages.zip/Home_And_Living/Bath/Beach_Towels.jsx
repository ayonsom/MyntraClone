﻿import React from 'react';

const BeachTowels = () => {
    return (
        <div>
            <h1>BeachTowels Component</h1>
        </div>
    );
}

export default BeachTowels;
