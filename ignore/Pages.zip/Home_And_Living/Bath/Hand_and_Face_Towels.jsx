﻿import React from 'react';

const HandAndFaceTowels = () => {
    return (
        <div>
            <h1>HandAndFaceTowels Component</h1>
        </div>
    );
}

export default HandAndFaceTowels;
