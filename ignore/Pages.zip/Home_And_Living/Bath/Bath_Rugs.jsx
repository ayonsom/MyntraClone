﻿import React from 'react';

const BathRugs = () => {
    return (
        <div>
            <h1>BathRugs Component</h1>
        </div>
    );
}

export default BathRugs;
