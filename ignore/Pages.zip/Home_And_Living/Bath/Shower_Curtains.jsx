﻿import React from 'react';

const ShowerCurtains = () => {
    return (
        <div>
            <h1>ShowerCurtains Component</h1>
        </div>
    );
}

export default ShowerCurtains;
