﻿import React from 'react';

const BathRobes = () => {
    return (
        <div>
            <h1>BathRobes Component</h1>
        </div>
    );
}

export default BathRobes;
