﻿import React from 'react';

const WallLamps = () => {
    return (
        <div>
            <h1>WallLamps Component</h1>
        </div>
    );
}

export default WallLamps;
