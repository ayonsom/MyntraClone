﻿import React from 'react';

const TableLamps = () => {
    return (
        <div>
            <h1>TableLamps Component</h1>
        </div>
    );
}

export default TableLamps;
