﻿import React from 'react';

const CeilingLamps = () => {
    return (
        <div>
            <h1>CeilingLamps Component</h1>
        </div>
    );
}

export default CeilingLamps;
