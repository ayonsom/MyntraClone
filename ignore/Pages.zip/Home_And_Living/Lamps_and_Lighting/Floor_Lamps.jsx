﻿import React from 'react';

const FloorLamps = () => {
    return (
        <div>
            <h1>FloorLamps Component</h1>
        </div>
    );
}

export default FloorLamps;
