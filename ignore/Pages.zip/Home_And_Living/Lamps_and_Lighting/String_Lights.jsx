﻿import React from 'react';

const StringLights = () => {
    return (
        <div>
            <h1>StringLights Component</h1>
        </div>
    );
}

export default StringLights;
