﻿import React from 'react';

const OutdoorLamps = () => {
    return (
        <div>
            <h1>OutdoorLamps Component</h1>
        </div>
    );
}

export default OutdoorLamps;
