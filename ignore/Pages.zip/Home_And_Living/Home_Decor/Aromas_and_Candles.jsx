﻿import React from 'react';

const AromasAndCandles = () => {
    return (
        <div>
            <h1>AromasAndCandles Component</h1>
        </div>
    );
}

export default AromasAndCandles;
