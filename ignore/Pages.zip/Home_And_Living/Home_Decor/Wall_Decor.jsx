﻿import React from 'react';

const WallDecor = () => {
    return (
        <div>
            <h1>WallDecor Component</h1>
        </div>
    );
}

export default WallDecor;
