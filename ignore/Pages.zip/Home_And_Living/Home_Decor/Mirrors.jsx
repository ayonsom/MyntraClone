﻿import React from 'react';

const Mirrors = () => {
    return (
        <div>
            <h1>Mirrors Component</h1>
        </div>
    );
}

export default Mirrors;
