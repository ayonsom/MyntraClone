﻿import React from 'react';

const Fountains = () => {
    return (
        <div>
            <h1>Fountains Component</h1>
        </div>
    );
}

export default Fountains;
