﻿import React from 'react';

const WallShelves = () => {
    return (
        <div>
            <h1>WallShelves Component</h1>
        </div>
    );
}

export default WallShelves;
