﻿import React from 'react';

const Clocks = () => {
    return (
        <div>
            <h1>Clocks Component</h1>
        </div>
    );
}

export default Clocks;
