﻿import React from 'react';

const PlantsAndPlanters = () => {
    return (
        <div>
            <h1>PlantsAndPlanters Component</h1>
        </div>
    );
}

export default PlantsAndPlanters;
