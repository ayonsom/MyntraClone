﻿import React from 'react';

const FestiveDecor = () => {
    return (
        <div>
            <h1>FestiveDecor Component</h1>
        </div>
    );
}

export default FestiveDecor;
