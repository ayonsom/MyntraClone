﻿import React from 'react';

const ShowpiecesAndVases = () => {
    return (
        <div>
            <h1>ShowpiecesAndVases Component</h1>
        </div>
    );
}

export default ShowpiecesAndVases;
