﻿import React from 'react';

const PoojaEssentials = () => {
    return (
        <div>
            <h1>PoojaEssentials Component</h1>
        </div>
    );
}

export default PoojaEssentials;
