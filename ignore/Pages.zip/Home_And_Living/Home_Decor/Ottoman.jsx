﻿import React from 'react';

const Ottoman = () => {
    return (
        <div>
            <h1>Ottoman Component</h1>
        </div>
    );
}

export default Ottoman;
